﻿Imports System.Data.OleDb

Public Class Form1
    ' Variables para la conexión y manejo de datos
    Private conexion As OleDbConnection
    Private adaptador As OleDbDataAdapter
    Private dataset As DataSet
    Private bindingSource As BindingSource
    Private comandoBuilder As OleDbCommandBuilder

    ' Ruta de la base de datos
    Private cadenaConexion As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Programacion3\Empleados.mdb;"

    ' Eventos del formulario
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            conexion = New OleDbConnection(cadenaConexion)
            conexion.Open()
            MessageBox.Show("Conectado a la base de datos correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Cargar los datos de la tabla
            CargarDatos()

        Catch ex As Exception
            MessageBox.Show("Error al conectar con la base de datos: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub CargarDatos()
        Try
            Dim consulta As String = "SELECT * FROM Tabla1"
            adaptador = New OleDbDataAdapter(consulta, conexion)
            comandoBuilder = New OleDbCommandBuilder(adaptador)
            dataset = New DataSet()
            adaptador.Fill(dataset, "Tabla1")

            ' Configurar el BindingSource
            bindingSource = New BindingSource()
            bindingSource.DataSource = dataset.Tables("Tabla1")

            ' Enlazar los controles con los datos
            txtID.DataBindings.Clear()
            txtNombre.DataBindings.Clear()
            txtTelefono.DataBindings.Clear()
            txtSueldo.DataBindings.Clear()

            txtID.DataBindings.Add("Text", bindingSource, "ID")
            txtNombre.DataBindings.Add("Text", bindingSource, "NOMBRE")
            txtTelefono.DataBindings.Add("Text", bindingSource, "TELEFONO")
            txtSueldo.DataBindings.Add("Text", bindingSource, "SUELDO")

            ' Enlazar el BindingNavigator con el BindingSource
            BindingNavigatorSaveItem.BindingSource = bindingSource

            ' Actualizar el estado de los botones según la posición
            AddHandler bindingSource.PositionChanged, AddressOf ActualizarBotonesNavegacion

            ' Asignar eventos de los botones de navegación
            AddHandler BindingNavigatorMoveFirstItem.Click, AddressOf MoverPrimero
            AddHandler BindingNavigatorMovePreviousItem.Click, AddressOf MoverAnterior
            AddHandler BindingNavigatorMoveNextItem.Click, AddressOf MoverSiguiente
            AddHandler BindingNavigatorMoveLastItem.Click, AddressOf MoverUltimo

            ' Actualizar el estado inicial de los botones
            ActualizarBotonesNavegacion(Nothing, EventArgs.Empty)

        Catch ex As Exception
            MessageBox.Show("Error al cargar datos: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Guardar cambios en la base de datos
    Private Sub BindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorSaveItem.Click
        Try
            bindingSource.EndEdit()
            adaptador.Update(dataset.Tables("Tabla1"))
            dataset.AcceptChanges()
            MessageBox.Show("Cambios guardados correctamente.", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error al guardar los cambios: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Funciones de navegación
    Private Sub MoverPrimero(sender As Object, e As EventArgs)
        bindingSource.MoveFirst()
    End Sub

    Private Sub MoverAnterior(sender As Object, e As EventArgs)
        bindingSource.MovePrevious()
    End Sub

    Private Sub MoverSiguiente(sender As Object, e As EventArgs)
        bindingSource.MoveNext()
    End Sub

    Private Sub MoverUltimo(sender As Object, e As EventArgs)
        bindingSource.MoveLast()
    End Sub

    ' Actualizar el estado de los botones del BindingNavigator según la posición
    Private Sub ActualizarBotonesNavegacion(sender As Object, e As EventArgs)
        BindingNavigatorMoveFirstItem.Enabled = bindingSource.Position > 0
        BindingNavigatorMovePreviousItem.Enabled = bindingSource.Position > 0
        BindingNavigatorMoveNextItem.Enabled = bindingSource.Position < bindingSource.Count - 1
        BindingNavigatorMoveLastItem.Enabled = bindingSource.Position < bindingSource.Count - 1
    End Sub

    ' Botón para cargar datos
    Private Sub btnCargar_Click(sender As Object, e As EventArgs) Handles btnCargar.Click
        CargarDatos()
    End Sub

    ' Botón para cerrar el formulario
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        If conexion IsNot Nothing Then
            conexion.Close()
        End If
        Me.Close()
    End Sub
End Class
