﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtId = New System.Windows.Forms.TextBox()
        Me.Tabla1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EmpleadosDataSet = New Empleados.EmpleadosDataSet()
        Me.txtNombre = New System.Windows.Forms.TextBox()
        Me.txtTelefono = New System.Windows.Forms.TextBox()
        Me.txtSueldo = New System.Windows.Forms.TextBox()
        Me.Tabla1TableAdapter = New Empleados.EmpleadosDataSetTableAdapters.Tabla1TableAdapter()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnSiguiente = New System.Windows.Forms.Button()
        Me.bntSalir = New System.Windows.Forms.Button()
        Me.btnAnterior = New System.Windows.Forms.Button()
        CType(Me.Tabla1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmpleadosDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.Label1.Location = New System.Drawing.Point(12, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 35)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Id"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.Label2.Location = New System.Drawing.Point(12, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(102, 35)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nombre"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.Label3.Location = New System.Drawing.Point(12, 154)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 35)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Telefono"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.Label4.Location = New System.Drawing.Point(12, 202)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 35)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Sueldo"
        '
        'txtId
        '
        Me.txtId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Id", True))
        Me.txtId.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.txtId.Location = New System.Drawing.Point(149, 54)
        Me.txtId.Name = "txtId"
        Me.txtId.Size = New System.Drawing.Size(100, 41)
        Me.txtId.TabIndex = 4
        '
        'Tabla1BindingSource
        '
        Me.Tabla1BindingSource.DataMember = "Tabla1"
        Me.Tabla1BindingSource.DataSource = Me.EmpleadosDataSet
        '
        'EmpleadosDataSet
        '
        Me.EmpleadosDataSet.DataSetName = "EmpleadosDataSet"
        Me.EmpleadosDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtNombre
        '
        Me.txtNombre.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Nombre", True))
        Me.txtNombre.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.txtNombre.Location = New System.Drawing.Point(149, 101)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.Size = New System.Drawing.Size(305, 41)
        Me.txtNombre.TabIndex = 5
        '
        'txtTelefono
        '
        Me.txtTelefono.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Telefono", True))
        Me.txtTelefono.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.txtTelefono.Location = New System.Drawing.Point(149, 148)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(163, 41)
        Me.txtTelefono.TabIndex = 6
        '
        'txtSueldo
        '
        Me.txtSueldo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Sueldo", True))
        Me.txtSueldo.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.txtSueldo.Location = New System.Drawing.Point(149, 202)
        Me.txtSueldo.Name = "txtSueldo"
        Me.txtSueldo.Size = New System.Drawing.Size(100, 41)
        Me.txtSueldo.TabIndex = 7
        '
        'Tabla1TableAdapter
        '
        Me.Tabla1TableAdapter.ClearBeforeFill = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Light", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(143, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 35)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "EMPLEADOS"
        '
        'btnSiguiente
        '
        Me.btnSiguiente.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.btnSiguiente.Location = New System.Drawing.Point(12, 286)
        Me.btnSiguiente.Name = "btnSiguiente"
        Me.btnSiguiente.Size = New System.Drawing.Size(140, 46)
        Me.btnSiguiente.TabIndex = 9
        Me.btnSiguiente.Text = "Siguiente"
        Me.btnSiguiente.UseVisualStyleBackColor = True
        '
        'bntSalir
        '
        Me.bntSalir.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.bntSalir.Location = New System.Drawing.Point(323, 286)
        Me.bntSalir.Name = "bntSalir"
        Me.bntSalir.Size = New System.Drawing.Size(114, 47)
        Me.bntSalir.TabIndex = 10
        Me.bntSalir.Text = "Salir"
        Me.bntSalir.UseVisualStyleBackColor = True
        '
        'btnAnterior
        '
        Me.btnAnterior.Font = New System.Drawing.Font("Segoe UI Light", 15.0!)
        Me.btnAnterior.Location = New System.Drawing.Point(176, 285)
        Me.btnAnterior.Name = "btnAnterior"
        Me.btnAnterior.Size = New System.Drawing.Size(136, 47)
        Me.btnAnterior.TabIndex = 11
        Me.btnAnterior.Text = "Anterior"
        Me.btnAnterior.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(466, 365)
        Me.Controls.Add(Me.btnAnterior)
        Me.Controls.Add(Me.bntSalir)
        Me.Controls.Add(Me.btnSiguiente)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtSueldo)
        Me.Controls.Add(Me.txtTelefono)
        Me.Controls.Add(Me.txtNombre)
        Me.Controls.Add(Me.txtId)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Tabla1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmpleadosDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtId As TextBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtTelefono As TextBox
    Friend WithEvents txtSueldo As TextBox
    Friend WithEvents EmpleadosDataSet As EmpleadosDataSet
    Friend WithEvents Tabla1BindingSource As BindingSource
    Friend WithEvents Tabla1TableAdapter As EmpleadosDataSetTableAdapters.Tabla1TableAdapter
    Friend WithEvents Label5 As Label
    Friend WithEvents btnSiguiente As Button
    Friend WithEvents bntSalir As Button
    Friend WithEvents btnAnterior As Button
End Class
