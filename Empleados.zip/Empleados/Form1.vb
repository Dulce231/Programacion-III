﻿Imports System.Data.OleDb

Public Class Form1
    Dim pos As Integer = 0 ' Índice del registro actual
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Programacion3\empleados.mdb;"
    Dim conn As New OleDbConnection(connectionString)
    Dim dt As New DataTable()

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Abrir la conexión a la base de datos
        Try
            conn.Open()

            ' Cargar los datos en el DataTable
            Dim query As String = "SELECT * FROM Tabla1"
            Dim da As New OleDbDataAdapter(query, conn)
            da.Fill(dt)

            ' Mostrar el primer registro si existen filas
            If dt.Rows.Count > 0 Then
                MostrarDatos(pos)
            End If
        Catch ex As Exception
            MessageBox.Show("Error al conectar a la base de datos: " & ex.Message)
        End Try
    End Sub

    Private Sub MostrarDatos(pos As Integer)
        ' Verificar que la posición sea válida
        If pos >= 0 AndAlso pos < dt.Rows.Count Then
            ' Obtener la fila correspondiente
            Dim fila As DataRow = dt.Rows(pos)

            ' Mostrar los datos en los controles
            txtId.Text = fila("Id").ToString()
            txtNombre.Text = fila("Nombre").ToString()
            txtTelefono.Text = fila("Telefono").ToString()
            txtSueldo.Text = fila("Sueldo").ToString()
            ' Agrega más controles según las columnas de tu tabla
        End If
    End Sub

    Private Sub btnSiguiente_Click(sender As Object, e As EventArgs) Handles btnSiguiente.Click
        ' Avanzar al siguiente registro
        If pos < dt.Rows.Count - 1 Then
            pos += 1
            MostrarDatos(pos)
        Else
            MessageBox.Show("No hay más registros.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub btnAnterior_Click(sender As Object, e As EventArgs) Handles btnAnterior.Click
        ' Retroceder al registro anterior
        If pos > 0 Then
            pos -= 1
            MostrarDatos(pos)
        Else
            MessageBox.Show("Estás en el primer registro.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub bntSalir_Click(sender As Object, e As EventArgs) Handles bntSalir.Click
        ' Cerrar la conexión y el formulario
        conn.Close()
        Me.Close()
    End Sub

    Private Sub txtId_TextChanged(sender As Object, e As EventArgs) Handles txtId.TextChanged

    End Sub
End Class
