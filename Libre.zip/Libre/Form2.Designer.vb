﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkSerum = New System.Windows.Forms.CheckBox()
        Me.chkPonds = New System.Windows.Forms.CheckBox()
        Me.chkGarnier = New System.Windows.Forms.CheckBox()
        Me.chkCerave = New System.Windows.Forms.CheckBox()
        Me.chkFijador = New System.Windows.Forms.CheckBox()
        Me.chkMascara = New System.Windows.Forms.CheckBox()
        Me.chkRubor = New System.Windows.Forms.CheckBox()
        Me.chkBase = New System.Windows.Forms.CheckBox()
        Me.btnContinuar = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.pbxSerum = New System.Windows.Forms.PictureBox()
        Me.pbxCerave = New System.Windows.Forms.PictureBox()
        Me.pbxGel = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxSerum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxCerave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxGel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkSerum
        '
        Me.chkSerum.AutoSize = True
        Me.chkSerum.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkSerum.Location = New System.Drawing.Point(158, 101)
        Me.chkSerum.Name = "chkSerum"
        Me.chkSerum.Size = New System.Drawing.Size(185, 84)
        Me.chkSerum.TabIndex = 12
        Me.chkSerum.Text = "Sérum facial de noche" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Garnier Skin Active express " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "aclara vitamina c 30 ml    " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$269.00" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.chkSerum.UseVisualStyleBackColor = True
        '
        'chkPonds
        '
        Me.chkPonds.AutoSize = True
        Me.chkPonds.Location = New System.Drawing.Point(165, 495)
        Me.chkPonds.Name = "chkPonds"
        Me.chkPonds.Size = New System.Drawing.Size(178, 89)
        Me.chkPonds.TabIndex = 15
        Me.chkPonds.Text = "Gel facial Pond's Hydra" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Active hidratante ácido" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " hialurónico 110 g" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$145.00" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.chkPonds.UseVisualStyleBackColor = True
        '
        'chkGarnier
        '
        Me.chkGarnier.AutoSize = True
        Me.chkGarnier.Location = New System.Drawing.Point(171, 356)
        Me.chkGarnier.Name = "chkGarnier"
        Me.chkGarnier.Size = New System.Drawing.Size(176, 72)
        Me.chkGarnier.TabIndex = 14
        Me.chkGarnier.Text = "Gel facial Garnier Skin " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " matificante vitamina C" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " 50 ml" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$170.00"
        Me.chkGarnier.UseVisualStyleBackColor = True
        '
        'chkCerave
        '
        Me.chkCerave.AutoSize = True
        Me.chkCerave.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCerave.Location = New System.Drawing.Point(158, 230)
        Me.chkCerave.Name = "chkCerave"
        Me.chkCerave.Size = New System.Drawing.Size(166, 64)
        Me.chkCerave.TabIndex = 13
        Me.chkCerave.Text = "CeraVe Blemish Control " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cleanser 236ml" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$371.66" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.chkCerave.UseVisualStyleBackColor = True
        '
        'chkFijador
        '
        Me.chkFijador.AutoSize = True
        Me.chkFijador.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkFijador.Location = New System.Drawing.Point(502, 499)
        Me.chkFijador.Name = "chkFijador"
        Me.chkFijador.Size = New System.Drawing.Size(126, 84)
        Me.chkFijador.TabIndex = 23
        Me.chkFijador.Text = "Spray fijador de " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "maquillaje Yuya" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " matificante 60 ml" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$155.00"
        Me.chkFijador.UseVisualStyleBackColor = True
        '
        'chkMascara
        '
        Me.chkMascara.AutoSize = True
        Me.chkMascara.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMascara.Location = New System.Drawing.Point(502, 356)
        Me.chkMascara.Name = "chkMascara"
        Me.chkMascara.Size = New System.Drawing.Size(159, 84)
        Me.chkMascara.TabIndex = 22
        Me.chkMascara.Text = "Máscara para pestañas" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Maybelline muy negro" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " 6 ml" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$209.00"
        Me.chkMascara.UseVisualStyleBackColor = True
        '
        'chkRubor
        '
        Me.chkRubor.AutoSize = True
        Me.chkRubor.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkRubor.Location = New System.Drawing.Point(502, 224)
        Me.chkRubor.Name = "chkRubor"
        Me.chkRubor.Size = New System.Drawing.Size(171, 64)
        Me.chkRubor.TabIndex = 21
        Me.chkRubor.Text = "Rubor en polvo Covergirl " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "trublend rosa 10 g" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$200" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.chkRubor.UseVisualStyleBackColor = True
        '
        'chkBase
        '
        Me.chkBase.AutoSize = True
        Me.chkBase.Font = New System.Drawing.Font("Arial Narrow", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBase.Location = New System.Drawing.Point(502, 104)
        Me.chkBase.Name = "chkBase"
        Me.chkBase.Size = New System.Drawing.Size(162, 84)
        Me.chkBase.TabIndex = 20
        Me.chkBase.Text = "Base de maquillaje" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Maybelline" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " New York Fit Me!  30 ml" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$189.00"
        Me.chkBase.UseVisualStyleBackColor = True
        '
        'btnContinuar
        '
        Me.btnContinuar.BackColor = System.Drawing.Color.LavenderBlush
        Me.btnContinuar.Font = New System.Drawing.Font("PMingLiU-ExtB", 15.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnContinuar.Location = New System.Drawing.Point(528, 613)
        Me.btnContinuar.Name = "btnContinuar"
        Me.btnContinuar.Size = New System.Drawing.Size(175, 53)
        Me.btnContinuar.TabIndex = 24
        Me.btnContinuar.Text = "CONTINUAR"
        Me.btnContinuar.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Perpetua Titling MT", 22.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(172, 19)
        Me.Label2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(403, 44)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Skincare y Belleza"
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.Libre.My.Resources.Resources.mascara
        Me.PictureBox7.Location = New System.Drawing.Point(360, 356)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(113, 89)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 18
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.Libre.My.Resources.Resources.rubor
        Me.PictureBox6.Location = New System.Drawing.Point(360, 224)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(113, 85)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 17
        Me.PictureBox6.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.Libre.My.Resources.Resources.Fijador
        Me.PictureBox8.Location = New System.Drawing.Point(360, 499)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(113, 95)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 19
        Me.PictureBox8.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.Libre.My.Resources.Resources.base
        Me.PictureBox5.Location = New System.Drawing.Point(360, 104)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(113, 88)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 16
        Me.PictureBox5.TabStop = False
        '
        'pbxSerum
        '
        Me.pbxSerum.Image = Global.Libre.My.Resources.Resources.Garnier
        Me.pbxSerum.Location = New System.Drawing.Point(43, 104)
        Me.pbxSerum.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.pbxSerum.Name = "pbxSerum"
        Me.pbxSerum.Size = New System.Drawing.Size(107, 88)
        Me.pbxSerum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxSerum.TabIndex = 8
        Me.pbxSerum.TabStop = False
        '
        'pbxCerave
        '
        Me.pbxCerave.Image = Global.Libre.My.Resources.Resources.cerave
        Me.pbxCerave.Location = New System.Drawing.Point(36, 224)
        Me.pbxCerave.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.pbxCerave.Name = "pbxCerave"
        Me.pbxCerave.Size = New System.Drawing.Size(113, 85)
        Me.pbxCerave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxCerave.TabIndex = 9
        Me.pbxCerave.TabStop = False
        '
        'pbxGel
        '
        Me.pbxGel.Image = Global.Libre.My.Resources.Resources.gel_garnier
        Me.pbxGel.Location = New System.Drawing.Point(36, 356)
        Me.pbxGel.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.pbxGel.Name = "pbxGel"
        Me.pbxGel.Size = New System.Drawing.Size(113, 89)
        Me.pbxGel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxGel.TabIndex = 10
        Me.pbxGel.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Libre.My.Resources.Resources.ponds
        Me.PictureBox4.Location = New System.Drawing.Point(36, 499)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(113, 95)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 11
        Me.PictureBox4.TabStop = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LavenderBlush
        Me.ClientSize = New System.Drawing.Size(763, 703)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnContinuar)
        Me.Controls.Add(Me.chkFijador)
        Me.Controls.Add(Me.chkMascara)
        Me.Controls.Add(Me.chkRubor)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.chkBase)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.chkSerum)
        Me.Controls.Add(Me.chkPonds)
        Me.Controls.Add(Me.chkGarnier)
        Me.Controls.Add(Me.chkCerave)
        Me.Controls.Add(Me.pbxSerum)
        Me.Controls.Add(Me.pbxCerave)
        Me.Controls.Add(Me.pbxGel)
        Me.Controls.Add(Me.PictureBox4)
        Me.Name = "Form2"
        Me.Text = "Articulos"
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxSerum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxCerave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxGel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents chkSerum As CheckBox
    Friend WithEvents chkPonds As CheckBox
    Friend WithEvents chkGarnier As CheckBox
    Friend WithEvents chkCerave As CheckBox
    Friend WithEvents pbxSerum As PictureBox
    Friend WithEvents pbxCerave As PictureBox
    Friend WithEvents pbxGel As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents chkFijador As CheckBox
    Friend WithEvents chkMascara As CheckBox
    Friend WithEvents chkRubor As CheckBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents chkBase As CheckBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents btnContinuar As Button
    Friend WithEvents Label2 As Label
End Class
