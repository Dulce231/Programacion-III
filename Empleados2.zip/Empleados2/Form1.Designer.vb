﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim IdLabel As System.Windows.Forms.Label
        Dim NombreLabel As System.Windows.Forms.Label
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtPastel = New System.Windows.Forms.TextBox()
        Me.picFoto = New System.Windows.Forms.PictureBox()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.btnCargarFoto = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.btnModificar = New System.Windows.Forms.Button()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.btnAgregar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.txtRelleno = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        IdLabel = New System.Windows.Forms.Label()
        NombreLabel = New System.Windows.Forms.Label()
        CType(Me.picFoto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IdLabel
        '
        IdLabel.AutoSize = True
        IdLabel.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IdLabel.Location = New System.Drawing.Point(42, 100)
        IdLabel.Name = "IdLabel"
        IdLabel.Size = New System.Drawing.Size(35, 23)
        IdLabel.TabIndex = 11
        IdLabel.Text = "Id:"
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NombreLabel.Location = New System.Drawing.Point(42, 145)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(80, 23)
        NombreLabel.TabIndex = 13
        NombreLabel.Text = "Pastel:"
        '
        'txtID
        '
        Me.txtID.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtID.Location = New System.Drawing.Point(179, 92)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(189, 31)
        Me.txtID.TabIndex = 12
        '
        'txtPastel
        '
        Me.txtPastel.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtPastel.Location = New System.Drawing.Point(179, 137)
        Me.txtPastel.Name = "txtPastel"
        Me.txtPastel.Size = New System.Drawing.Size(189, 31)
        Me.txtPastel.TabIndex = 14
        '
        'picFoto
        '
        Me.picFoto.Location = New System.Drawing.Point(421, 37)
        Me.picFoto.Name = "picFoto"
        Me.picFoto.Size = New System.Drawing.Size(177, 196)
        Me.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFoto.TabIndex = 21
        Me.picFoto.TabStop = False
        '
        'btnEliminar
        '
        Me.btnEliminar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnEliminar.Location = New System.Drawing.Point(168, 307)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(105, 44)
        Me.btnEliminar.TabIndex = 28
        Me.btnEliminar.Text = "Eliminar"
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'btnCargarFoto
        '
        Me.btnCargarFoto.BackColor = System.Drawing.Color.LightGreen
        Me.btnCargarFoto.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnCargarFoto.Location = New System.Drawing.Point(435, 247)
        Me.btnCargarFoto.Name = "btnCargarFoto"
        Me.btnCargarFoto.Size = New System.Drawing.Size(119, 43)
        Me.btnCargarFoto.TabIndex = 27
        Me.btnCargarFoto.Text = "Cargar Foto"
        Me.btnCargarFoto.UseVisualStyleBackColor = False
        '
        'btnSalir
        '
        Me.btnSalir.BackColor = System.Drawing.Color.Red
        Me.btnSalir.Cursor = System.Windows.Forms.Cursors.No
        Me.btnSalir.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnSalir.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnSalir.Location = New System.Drawing.Point(513, 394)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(105, 44)
        Me.btnSalir.TabIndex = 26
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = False
        '
        'btnModificar
        '
        Me.btnModificar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnModificar.Location = New System.Drawing.Point(324, 373)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(105, 44)
        Me.btnModificar.TabIndex = 25
        Me.btnModificar.Text = "Modificar"
        Me.btnModificar.UseVisualStyleBackColor = True
        '
        'btnBuscar
        '
        Me.btnBuscar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnBuscar.Location = New System.Drawing.Point(324, 307)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(105, 44)
        Me.btnBuscar.TabIndex = 24
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = True
        '
        'btnLimpiar
        '
        Me.btnLimpiar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnLimpiar.Location = New System.Drawing.Point(20, 373)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(105, 44)
        Me.btnLimpiar.TabIndex = 23
        Me.btnLimpiar.Text = "Limpiar"
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'btnAgregar
        '
        Me.btnAgregar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnAgregar.Location = New System.Drawing.Point(20, 307)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(105, 44)
        Me.btnAgregar.TabIndex = 22
        Me.btnAgregar.Text = "Agregar"
        Me.btnAgregar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Perpetua Titling MT", 15.0!)
        Me.Label1.Location = New System.Drawing.Point(26, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(161, 30)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "Pasteleria "
        '
        'OleDbConnection1
        '
        Me.OleDbConnection1.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Programacion3\Empleados2\Pasteles" &
    ".mdb"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'txtRelleno
        '
        Me.txtRelleno.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtRelleno.Location = New System.Drawing.Point(179, 179)
        Me.txtRelleno.Multiline = True
        Me.txtRelleno.Name = "txtRelleno"
        Me.txtRelleno.Size = New System.Drawing.Size(189, 28)
        Me.txtRelleno.TabIndex = 30
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(46, 184)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 23)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Relleno:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(644, 450)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtRelleno)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnEliminar)
        Me.Controls.Add(Me.btnCargarFoto)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnModificar)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.btnAgregar)
        Me.Controls.Add(Me.picFoto)
        Me.Controls.Add(IdLabel)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(NombreLabel)
        Me.Controls.Add(Me.txtPastel)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.picFoto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtPastel As TextBox
    Friend WithEvents picFoto As PictureBox
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnCargarFoto As Button
    Friend WithEvents btnSalir As Button
    Friend WithEvents btnModificar As Button
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents OleDbConnection1 As OleDb.OleDbConnection
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents txtRelleno As TextBox
    Friend WithEvents Label2 As Label
End Class
