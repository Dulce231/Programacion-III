﻿Imports System.Data.OleDb
Public Class Form1

    Dim Cnx As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Programacion3\Empleados2\Pasteles.mdb;")
    Dim strFileName As String

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        ' Validar que los campos no estén vacíos
        If String.IsNullOrEmpty(txtID.Text) OrElse String.IsNullOrEmpty(txtPastel.Text) OrElse String.IsNullOrEmpty(txtRelleno.Text) Then
            MsgBox("Por favor, complete todos los campos.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            Dim insertar = "INSERT INTO Tabla1 (Id, Pastel, Relleno, Foto) VALUES (@Id, @Pastel, @Relleno, @Foto)"
            Dim cmd As New OleDbCommand(insertar, Cnx)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@Id", txtID.Text)
            cmd.Parameters.AddWithValue("@Pastel", txtPastel.Text)
            cmd.Parameters.AddWithValue("@Relleno", txtRelleno.Text)
            cmd.Parameters.AddWithValue("@Foto", If(String.IsNullOrEmpty(strFileName), DBNull.Value, strFileName))

            Cnx.Open()
            cmd.ExecuteNonQuery()
            MsgBox("Pastel registrado correctamente.", MsgBoxStyle.Information, "Éxito")
        Catch ex As Exception
            MsgBox("Error al agregar el pastel: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try

        LimpiarCampos()
    End Sub

    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        If String.IsNullOrEmpty(txtID.Text) Then
            MsgBox("Por favor, ingrese un ID para buscar.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            Dim buscar = "SELECT * FROM Tabla1 WHERE Id=@Id"
            Dim cmdBuscar As New OleDbCommand(buscar, Cnx)
            cmdBuscar.Parameters.AddWithValue("@Id", txtID.Text)

            Cnx.Open()
            Dim lectura As OleDbDataReader = cmdBuscar.ExecuteReader()

            If lectura.Read() Then
                txtPastel.Text = lectura("Pastel").ToString()
                txtRelleno.Text = lectura("Relleno").ToString()
                picFoto.ImageLocation = lectura("Foto").ToString()
            Else
                MsgBox("El pastel no está registrado.", MsgBoxStyle.Information, "Pasteles")
                txtID.Clear()
            End If
        Catch ex As Exception
            MsgBox("Error al buscar el pastel: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try
    End Sub

    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        If String.IsNullOrEmpty(txtID.Text) Then
            MsgBox("Por favor, ingrese un ID para modificar.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            Dim actualizar = "UPDATE Tabla1 SET Pastel=@Pastel, Relleno=@Relleno, Foto=@Foto WHERE Id=@Id"
            Dim cmd As New OleDbCommand(actualizar, Cnx)
            cmd.Parameters.AddWithValue("@Pastel", txtPastel.Text)
            cmd.Parameters.AddWithValue("@Relleno", txtRelleno.Text)
            cmd.Parameters.AddWithValue("@Foto", If(String.IsNullOrEmpty(strFileName), DBNull.Value, strFileName))
            cmd.Parameters.AddWithValue("@Id", txtID.Text)

            Cnx.Open()
            cmd.ExecuteNonQuery()
            MsgBox("Pastel actualizado correctamente.", MsgBoxStyle.Information, "Éxito")
        Catch ex As Exception
            MsgBox("Error al modificar el pastel: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        If String.IsNullOrEmpty(txtID.Text) Then
            MsgBox("Por favor, ingrese un ID para eliminar.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            Dim eliminar = "DELETE FROM Tabla1 WHERE Id=@Id"
            Dim cmd As New OleDbCommand(eliminar, Cnx)
            cmd.Parameters.AddWithValue("@Id", txtID.Text)

            Cnx.Open()
            cmd.ExecuteNonQuery()
            MsgBox("Pastel eliminado correctamente.", MsgBoxStyle.Information, "Éxito")
        Catch ex As Exception
            MsgBox("Error al eliminar el pastel: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try

        LimpiarCampos()
    End Sub

    Private Sub btnCargarFoto_Click(sender As Object, e As EventArgs) Handles btnCargarFoto.Click
        With OpenFileDialog1
            .Filter = "Imágenes|*.jpg;*.jpeg;*.png;*.bmp"
            .FilterIndex = 1
            .Title = "Seleccionar una imagen"
        End With

        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Try
                strFileName = OpenFileDialog1.FileName
                picFoto.Image = Image.FromFile(strFileName)
            Catch ex As Exception
                MsgBox("Error al cargar la imagen: " & ex.Message, MsgBoxStyle.Critical, "Error")
            End Try
        End If
    End Sub

    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        LimpiarCampos()
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub LimpiarCampos()
        txtID.Clear()
        txtPastel.Clear()
        txtRelleno.Clear()
        picFoto.Image = Nothing
        strFileName = String.Empty
        txtID.Focus()
    End Sub

End Class