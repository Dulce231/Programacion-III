﻿Public Class Form1
    Private Sub btnEntrar_Click(sender As Object, e As EventArgs) Handles btnEntrar.Click
        Form2.Show()
        Me.Hide()
    End Sub
End Class