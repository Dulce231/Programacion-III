﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IdLabel As System.Windows.Forms.Label
        Dim NombreLabel As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtArtista = New System.Windows.Forms.TextBox()
        Me.Tabla1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MusicaDataSet = New Musica.MusicaDataSet()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.btnCargarFoto = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.btnModificar = New System.Windows.Forms.Button()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.btnAgregar = New System.Windows.Forms.Button()
        Me.picFoto = New System.Windows.Forms.PictureBox()
        Me.Tabla1BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.MusicaDataSet1 = New Musica.MusicaDataSet1()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtAlbum = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtGenero = New System.Windows.Forms.TextBox()
        Me.txtDiscografia = New System.Windows.Forms.TextBox()
        Me.txtAño = New System.Windows.Forms.TextBox()
        Me.Tabla1TableAdapter1 = New Musica.MusicaDataSet1TableAdapters.Tabla1TableAdapter()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.MusicaDataSet2 = New Musica.MusicaDataSet2()
        Me.MusicaDataSet2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Tabla2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Tabla2TableAdapter = New Musica.MusicaDataSet2TableAdapters.Tabla2TableAdapter()
        IdLabel = New System.Windows.Forms.Label()
        NombreLabel = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Tabla1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFoto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Tabla1BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicaDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicaDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicaDataSet2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Tabla2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IdLabel
        '
        IdLabel.AutoSize = True
        IdLabel.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        IdLabel.Location = New System.Drawing.Point(34, 49)
        IdLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        IdLabel.Name = "IdLabel"
        IdLabel.Size = New System.Drawing.Size(35, 23)
        IdLabel.TabIndex = 47
        IdLabel.Text = "Id:"
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NombreLabel.Location = New System.Drawing.Point(34, 109)
        NombreLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(78, 23)
        NombreLabel.TabIndex = 49
        NombreLabel.Text = "Album"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label3.Location = New System.Drawing.Point(34, 209)
        Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(145, 23)
        Label3.TabIndex = 62
        Label3.Text = "Discografia"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label4.Location = New System.Drawing.Point(34, 264)
        Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(57, 23)
        Label4.TabIndex = 64
        Label4.Text = "Año"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Musica.My.Resources.Resources.ea_ea_ea_ea
        Me.PictureBox1.Location = New System.Drawing.Point(15, 15)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(959, 532)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(34, 162)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 23)
        Me.Label2.TabIndex = 61
        Me.Label2.Text = "Artista"
        '
        'txtArtista
        '
        Me.txtArtista.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Artista", True))
        Me.txtArtista.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtArtista.Location = New System.Drawing.Point(204, 151)
        Me.txtArtista.Margin = New System.Windows.Forms.Padding(4)
        Me.txtArtista.Multiline = True
        Me.txtArtista.Name = "txtArtista"
        Me.txtArtista.Size = New System.Drawing.Size(235, 34)
        Me.txtArtista.TabIndex = 60
        '
        'Tabla1BindingSource
        '
        Me.Tabla1BindingSource.DataMember = "Tabla1"
        Me.Tabla1BindingSource.DataSource = Me.MusicaDataSet
        '
        'MusicaDataSet
        '
        Me.MusicaDataSet.DataSetName = "MusicaDataSet"
        Me.MusicaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnEliminar
        '
        Me.btnEliminar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnEliminar.Location = New System.Drawing.Point(334, 388)
        Me.btnEliminar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(131, 55)
        Me.btnEliminar.TabIndex = 58
        Me.btnEliminar.Text = "Eliminar"
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'btnCargarFoto
        '
        Me.btnCargarFoto.BackColor = System.Drawing.Color.LightGreen
        Me.btnCargarFoto.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnCargarFoto.Location = New System.Drawing.Point(709, 316)
        Me.btnCargarFoto.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCargarFoto.Name = "btnCargarFoto"
        Me.btnCargarFoto.Size = New System.Drawing.Size(149, 54)
        Me.btnCargarFoto.TabIndex = 57
        Me.btnCargarFoto.Text = "Cargar Foto"
        Me.btnCargarFoto.UseVisualStyleBackColor = False
        '
        'btnSalir
        '
        Me.btnSalir.BackColor = System.Drawing.Color.Red
        Me.btnSalir.Cursor = System.Windows.Forms.Cursors.No
        Me.btnSalir.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnSalir.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnSalir.Location = New System.Drawing.Point(738, 470)
        Me.btnSalir.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(131, 55)
        Me.btnSalir.TabIndex = 56
        Me.btnSalir.Text = "Salir"
        Me.btnSalir.UseVisualStyleBackColor = False
        '
        'btnModificar
        '
        Me.btnModificar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnModificar.Location = New System.Drawing.Point(446, 470)
        Me.btnModificar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(131, 55)
        Me.btnModificar.TabIndex = 55
        Me.btnModificar.Text = "Modificar"
        Me.btnModificar.UseVisualStyleBackColor = True
        '
        'btnBuscar
        '
        Me.btnBuscar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnBuscar.Location = New System.Drawing.Point(536, 388)
        Me.btnBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(131, 55)
        Me.btnBuscar.TabIndex = 54
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = True
        '
        'btnLimpiar
        '
        Me.btnLimpiar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnLimpiar.Location = New System.Drawing.Point(232, 470)
        Me.btnLimpiar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(131, 55)
        Me.btnLimpiar.TabIndex = 53
        Me.btnLimpiar.Text = "Limpiar"
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'btnAgregar
        '
        Me.btnAgregar.Font = New System.Drawing.Font("Perpetua Titling MT", 9.0!)
        Me.btnAgregar.Location = New System.Drawing.Point(110, 388)
        Me.btnAgregar.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAgregar.Name = "btnAgregar"
        Me.btnAgregar.Size = New System.Drawing.Size(131, 55)
        Me.btnAgregar.TabIndex = 52
        Me.btnAgregar.Text = "Agregar"
        Me.btnAgregar.UseVisualStyleBackColor = True
        '
        'picFoto
        '
        Me.picFoto.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.Tabla1BindingSource1, "Foto", True))
        Me.picFoto.Location = New System.Drawing.Point(536, 42)
        Me.picFoto.Margin = New System.Windows.Forms.Padding(4)
        Me.picFoto.Name = "picFoto"
        Me.picFoto.Size = New System.Drawing.Size(398, 250)
        Me.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFoto.TabIndex = 51
        Me.picFoto.TabStop = False
        '
        'Tabla1BindingSource1
        '
        Me.Tabla1BindingSource1.DataMember = "Tabla1"
        Me.Tabla1BindingSource1.DataSource = Me.MusicaDataSet1
        '
        'MusicaDataSet1
        '
        Me.MusicaDataSet1.DataSetName = "MusicaDataSet1"
        Me.MusicaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'txtID
        '
        Me.txtID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Id", True))
        Me.txtID.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtID.Location = New System.Drawing.Point(204, 41)
        Me.txtID.Margin = New System.Windows.Forms.Padding(4)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(235, 31)
        Me.txtID.TabIndex = 48
        '
        'txtAlbum
        '
        Me.txtAlbum.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Album", True))
        Me.txtAlbum.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtAlbum.Location = New System.Drawing.Point(204, 101)
        Me.txtAlbum.Margin = New System.Windows.Forms.Padding(4)
        Me.txtAlbum.Name = "txtAlbum"
        Me.txtAlbum.Size = New System.Drawing.Size(235, 31)
        Me.txtAlbum.TabIndex = 50
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(34, 327)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 23)
        Me.Label1.TabIndex = 67
        Me.Label1.Text = "Genero"
        '
        'txtGenero
        '
        Me.txtGenero.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Genero", True))
        Me.txtGenero.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtGenero.Location = New System.Drawing.Point(204, 316)
        Me.txtGenero.Margin = New System.Windows.Forms.Padding(4)
        Me.txtGenero.Multiline = True
        Me.txtGenero.Name = "txtGenero"
        Me.txtGenero.Size = New System.Drawing.Size(235, 34)
        Me.txtGenero.TabIndex = 66
        '
        'txtDiscografia
        '
        Me.txtDiscografia.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Discografia", True))
        Me.txtDiscografia.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtDiscografia.Location = New System.Drawing.Point(204, 201)
        Me.txtDiscografia.Margin = New System.Windows.Forms.Padding(4)
        Me.txtDiscografia.Name = "txtDiscografia"
        Me.txtDiscografia.Size = New System.Drawing.Size(235, 31)
        Me.txtDiscografia.TabIndex = 63
        '
        'txtAño
        '
        Me.txtAño.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Tabla1BindingSource, "Año", True))
        Me.txtAño.Font = New System.Drawing.Font("Perpetua Titling MT", 12.0!)
        Me.txtAño.Location = New System.Drawing.Point(204, 261)
        Me.txtAño.Margin = New System.Windows.Forms.Padding(4)
        Me.txtAño.Name = "txtAño"
        Me.txtAño.Size = New System.Drawing.Size(235, 31)
        Me.txtAño.TabIndex = 65
        '
        'Tabla1TableAdapter1
        '
        Me.Tabla1TableAdapter1.ClearBeforeFill = True
        '
        'MusicaDataSet2
        '
        Me.MusicaDataSet2.DataSetName = "MusicaDataSet2"
        Me.MusicaDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MusicaDataSet2BindingSource
        '
        Me.MusicaDataSet2BindingSource.DataSource = Me.MusicaDataSet2
        Me.MusicaDataSet2BindingSource.Position = 0
        '
        'Tabla2BindingSource
        '
        Me.Tabla2BindingSource.DataMember = "Tabla2"
        Me.Tabla2BindingSource.DataSource = Me.MusicaDataSet2BindingSource
        '
        'Tabla2TableAdapter
        '
        Me.Tabla2TableAdapter.ClearBeforeFill = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.OliveDrab
        Me.ClientSize = New System.Drawing.Size(1000, 562)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtGenero)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Me.txtDiscografia)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Me.txtAño)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtArtista)
        Me.Controls.Add(Me.btnEliminar)
        Me.Controls.Add(Me.btnCargarFoto)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnModificar)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.btnAgregar)
        Me.Controls.Add(Me.picFoto)
        Me.Controls.Add(IdLabel)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(NombreLabel)
        Me.Controls.Add(Me.txtAlbum)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Tabla1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFoto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Tabla1BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicaDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicaDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicaDataSet2BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Tabla2BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtArtista As TextBox
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnCargarFoto As Button
    Friend WithEvents btnSalir As Button
    Friend WithEvents btnModificar As Button
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents picFoto As PictureBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtAlbum As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtGenero As TextBox
    Friend WithEvents txtDiscografia As TextBox
    Friend WithEvents txtAño As TextBox
    Friend WithEvents MusicaDataSet As MusicaDataSet
    Friend WithEvents Tabla1BindingSource As BindingSource

    Friend WithEvents MusicaDataSet1 As MusicaDataSet1
    Friend WithEvents Tabla1BindingSource1 As BindingSource
    Friend WithEvents Tabla1TableAdapter1 As MusicaDataSet1TableAdapters.Tabla1TableAdapter
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents MusicaDataSet2 As MusicaDataSet2
    Friend WithEvents MusicaDataSet2BindingSource As BindingSource
    Friend WithEvents Tabla2BindingSource As BindingSource
    Friend WithEvents Tabla2TableAdapter As MusicaDataSet2TableAdapters.Tabla2TableAdapter
End Class
