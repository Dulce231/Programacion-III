﻿Imports System.Data.OleDb

Public Class Form3

    Dim Cnx As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Programacion3\Musica\Musica.mdb;")
    Dim strFileName As String
    Dim ds As New DataSet()  ' Declaramos el DataSet
    Dim adapter As OleDbDataAdapter  ' Declaramos el DataAdapter

    ' Este código se ejecuta al cargar el formulario
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ' Configuramos el DataAdapter y cargamos los datos
            adapter = New OleDbDataAdapter("SELECT * FROM Tabla1", Cnx)
            adapter.Fill(ds, "Tabla1")  ' Llenamos el DataSet con los datos de la tabla Tabla1

            ' Verificamos si la tabla se cargó correctamente
            If ds.Tables.Contains("Tabla1") Then
                MsgBox("La tabla 'Tabla1' se cargó correctamente.", MsgBoxStyle.Information, "Éxito")
            Else
                MsgBox("La tabla 'Tabla1' no se encontró en el DataSet.", MsgBoxStyle.Exclamation, "Error")
            End If
        Catch ex As Exception
            MsgBox("Error al cargar los datos: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    ' Método para agregar un álbum
    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        If String.IsNullOrEmpty(txtID.Text) OrElse String.IsNullOrEmpty(txtAlbum.Text) OrElse String.IsNullOrEmpty(txtArtista.Text) Then
            MsgBox("Por favor, complete todos los campos.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            ' Sentencia SQL para insertar el álbum
            Dim insertar = "INSERT INTO Tabla1 (Id, Album, Artista, Discografia, Año, Genero, Foto) VALUES (@Id, @Album, @Artista, @Discografia, @Año, @Genero, @Foto)"
            Dim cmd As New OleDbCommand(insertar, Cnx)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@Id", txtID.Text)
            cmd.Parameters.AddWithValue("@Album", txtAlbum.Text)
            cmd.Parameters.AddWithValue("@Artista", txtArtista.Text)
            cmd.Parameters.AddWithValue("@Discografia", txtDiscografia.Text)
            cmd.Parameters.AddWithValue("@Año", txtAño.Text)
            cmd.Parameters.AddWithValue("@Genero", txtGenero.Text)
            cmd.Parameters.AddWithValue("@Foto", If(String.IsNullOrEmpty(strFileName), DBNull.Value, strFileName))

            Cnx.Open()
            cmd.ExecuteNonQuery()
            MsgBox("Álbum registrado correctamente.", MsgBoxStyle.Information, "Éxito")

            ' Recargamos los datos después de la inserción
            ds.Tables("Tabla1").Clear()
            adapter.Fill(ds, "Tabla1")

        Catch ex As Exception
            MsgBox("Error al agregar el álbum: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try

        LimpiarCampos()
    End Sub

    ' Método para buscar un álbum
    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        If String.IsNullOrEmpty(txtID.Text) Then
            MsgBox("Por favor, ingrese un ID para buscar.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            Dim buscar = "SELECT * FROM Tabla1 WHERE Id=@Id"
            Dim cmdBuscar As New OleDbCommand(buscar, Cnx)
            cmdBuscar.Parameters.AddWithValue("@Id", txtID.Text)

            Cnx.Open()
            Dim lectura As OleDbDataReader = cmdBuscar.ExecuteReader()

            If lectura.Read() Then
                txtAlbum.Text = lectura("Album").ToString()
                txtArtista.Text = lectura("Artista").ToString()
                txtDiscografia.Text = lectura("Discografia").ToString()
                txtAño.Text = lectura("Año").ToString()
                txtGenero.Text = lectura("Genero").ToString()
                picFoto.ImageLocation = lectura("Foto").ToString()
            Else
                MsgBox("El álbum no está registrado.", MsgBoxStyle.Information, "Música")
                txtID.Clear()
            End If
        Catch ex As Exception
            MsgBox("Error al buscar el álbum: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try
    End Sub

    ' Método para modificar un álbum
    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        If String.IsNullOrEmpty(txtID.Text) Then
            MsgBox("Por favor, ingrese un ID para modificar.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            Dim actualizar = "UPDATE Tabla1 SET Album=@Album, Artista=@Artista, Discografia=@Discografia, Año=@Año, Genero=@Genero, Foto=@Foto WHERE Id=@Id"
            Dim cmd As New OleDbCommand(actualizar, Cnx)
            cmd.Parameters.AddWithValue("@Album", txtAlbum.Text)
            cmd.Parameters.AddWithValue("@Artista", txtArtista.Text)
            cmd.Parameters.AddWithValue("@Discografia", txtDiscografia.Text)
            cmd.Parameters.AddWithValue("@Año", txtAño.Text)
            cmd.Parameters.AddWithValue("@Genero", txtGenero.Text)
            cmd.Parameters.AddWithValue("@Foto", If(String.IsNullOrEmpty(strFileName), DBNull.Value, strFileName))
            cmd.Parameters.AddWithValue("@Id", txtID.Text)

            Cnx.Open()
            cmd.ExecuteNonQuery()
            MsgBox("Álbum actualizado correctamente.", MsgBoxStyle.Information, "Éxito")

            ' Recargamos los datos después de la actualización
            ds.Tables("Tabla1").Clear()
            adapter.Fill(ds, "Tabla1")

        Catch ex As Exception
            MsgBox("Error al modificar el álbum: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try
    End Sub

    ' Método para eliminar un álbum
    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        If String.IsNullOrEmpty(txtID.Text) Then
            MsgBox("Por favor, ingrese un ID para eliminar.", MsgBoxStyle.Exclamation, "Error")
            Return
        End If

        Try
            Dim eliminar = "DELETE FROM Tabla1 WHERE Id=@Id"
            Dim cmd As New OleDbCommand(eliminar, Cnx)
            cmd.Parameters.AddWithValue("@Id", txtID.Text)

            Cnx.Open()
            cmd.ExecuteNonQuery()
            MsgBox("Álbum eliminado correctamente.", MsgBoxStyle.Information, "Éxito")

            ' Recargamos los datos después de la eliminación
            ds.Tables("Tabla1").Clear()
            adapter.Fill(ds, "Tabla1")

        Catch ex As Exception
            MsgBox("Error al eliminar el álbum: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            If Cnx.State = ConnectionState.Open Then
                Cnx.Close()
            End If
        End Try

        LimpiarCampos()
    End Sub

    ' Método para limpiar los campos
    Private Sub LimpiarCampos()
        txtID.Clear()
        txtAlbum.Clear()
        txtArtista.Clear()
        txtDiscografia.Clear()
        txtAño.Clear()
        txtGenero.Clear()
        picFoto.Image = Nothing
        strFileName = String.Empty
        txtID.Focus()
    End Sub
End Class
