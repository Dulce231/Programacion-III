﻿Imports System.Data.OleDb

Public Class Form2
    ' Definir la conexión con la base de datos
    Dim Cnx As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Programacion3\Musica\Musica.mdb;")

    Private Sub btnValidar_Click(sender As Object, e As EventArgs) Handles btnValidar.Click
        Try
            ' Obtener valores de los TextBox
            Dim usuario As String = txtUsuario.Text.Trim()
            Dim contrasena As String = txtContrasena.Text.Trim()

            ' Verificar si los campos están vacíos
            If usuario = "" Or contrasena = "" Then
                MsgBox("Por favor, ingrese usuario y contraseña.", MsgBoxStyle.Exclamation, "Error")
                Return
            End If

            ' Consulta SQL con parámetros sin nombre
            Dim consulta As String = "SELECT * FROM Tabla2 WHERE usuario = ? AND contraseña = ?"
            Dim cmd As New OleDbCommand(consulta, Cnx)

            ' Agregar los parámetros en el orden correcto
            cmd.Parameters.AddWithValue("?", usuario)  ' Primer parámetro (usuario)
            cmd.Parameters.AddWithValue("?", contrasena)  ' Segundo parámetro (contraseña)

            ' Abrir la conexión
            Cnx.Open()

            ' Ejecutar la consulta y obtener el lector
            Dim lector As OleDbDataReader = cmd.ExecuteReader()

            ' Validar si se encontraron resultados
            If lector.HasRows Then
                MsgBox("Acceso concedido.", MsgBoxStyle.Information, "Bienvenido")

                ' Opcional: Mensaje de confirmación antes de abrir Form3
                Dim respuesta As MsgBoxResult = MsgBox("¿Deseas continuar al siguiente formulario?", MsgBoxStyle.YesNo + MsgBoxStyle.Information, "Confirmación")

                If respuesta = MsgBoxResult.Yes Then
                    ' Mostrar Form3 y ocultar Form2
                    Form3.Show()
                    Me.Hide()
                End If
            Else
                MsgBox("Usuario o contraseña incorrectos.", MsgBoxStyle.Critical, "Error")
            End If

        Catch ex As Exception
            ' Mostrar error si ocurre
            MsgBox("Error al validar el usuario: " & ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            ' Cerrar la conexión si está abierta
            If Cnx.State = ConnectionState.Open Then Cnx.Close()
        End Try
    End Sub
End Class
